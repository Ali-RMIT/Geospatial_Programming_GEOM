"""
DataPlotly test suite
"""

# import qgis libs so that we set the correct sip api version
import qgis  # pylint: disable=W0401,W0614
